This is the source code for service uptime DS assignment.
